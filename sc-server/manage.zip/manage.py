#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys


def main():
    """Run administrative tasks."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

    # Set default port to 8082 when running runserver
    if len(sys.argv) >= 2 and sys.argv[1] == 'runserver':
        # If no port specified, add 8082
        if len(sys.argv) == 2:
            sys.argv.append('8082')
        # If default port 8000 is specified, change to 8082
        elif len(sys.argv) == 3 and sys.argv[2] == '8000':
            sys.argv[2] = '8082'
        # If there are flags like --noreload but no port
        elif len(sys.argv) == 3 and sys.argv[2].startswith('--'):
            sys.argv.insert(2, '8082')

    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
